const express = require('express');
const session = require('express-session');

var app = express();

app.use(express.static('public'));

app.use(session({ secret: 'XXassasas¨¨$', resave: false, saveUninitialized: true }));

app.get('/', function(req, res, next) {

    res.sendFile(__dirname + "/inicialjogodavelha.html");
});

app.get('/jogar.html', function(req, res, next) {

    res.sendFile(__dirname + "/jogar.html");
});

app.get('/playervsplayer.html', function(req, res, next) {

    res.sendFile(__dirname + "/playervsplayer.html");
});

app.get('/instrucoes.html', function(req, res, next) {

    res.sendFile(__dirname + "/instrucoes.html");
});

app.get('/sobre.html', function(req, res, next) {

    res.sendFile(__dirname + "/sobre.html");
});

app.listen(3000, () => {
  console.log('Escutando localhost:3000');
})